import { Component, OnInit } from "@angular/core";
import { Seller } from "../../shared/models/seller";
import { Router, ActivatedRoute } from "@angular/router";
import { SellerSharedService } from "../seller-shared.service";


@Component({
    selector: 'seller-home',
    templateUrl: './../seller-home/seller-home.component.html',

})
export class SellerHomeComponent implements OnInit {
    isViewProductSelected: boolean = false;
    optionSelected: string;
    loggedInSeller: Seller;
    constructor(private router: Router, private route: ActivatedRoute, private sharedService: SellerSharedService) {
    }

    ngOnInit() {
        this.sharedService.currentSeller.subscribe(seller => this.loggedInSeller = seller);
        this.loggedInSeller = JSON.parse(sessionStorage.getItem("seller"));

    }

    getAllProducts() {
        this.isViewProductSelected = !this.isViewProductSelected;
    }
    chosenOption(chosenOption: string) {
        this.optionSelected = chosenOption;
        if (chosenOption == "viewProfile") {
            this.router.navigate(["profile"], { relativeTo: this.route });
        } else if (chosenOption == "viewAllProducts") {

            this.router.navigate(["viewProducts"], { relativeTo: this.route });
        } else if (chosenOption == "changePassword") {
            this.router.navigate(["changePassword"], { relativeTo: this.route });
        }
        else if (chosenOption == "viewAllOrders") {

            this.router.navigate(["viewOrders"], { relativeTo: this.route });
        }
        else if (chosenOption == "addNewProduct") {

            this.router.navigate(["addProduct"], { relativeTo: this.route });
        }
        else if(chosenOption=="recommend")
        {
            this.router.navigate(["viewRecommend"],{relativeTo: this.route});
        }
        else if(chosenOption=="recommendNew")
        {
            this.router.navigate(["recommendNewProduct"],{relativeTo:this.route});
        }
    }

    update(seller: Seller) {
        this.loggedInSeller = seller;
    }

    logout() {
        sessionStorage.clear();
        this.router.navigate(["seller"]);
    }

}