import { TestBed, inject } from '@angular/core/testing';

import { SellerAddProductToRecommendService } from './seller-add-product-to-recommend.service';

describe('SellerAddProductToRecommendService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [SellerAddProductToRecommendService]
    });
  });

  it('should be created', inject([SellerAddProductToRecommendService], (service: SellerAddProductToRecommendService) => {
    expect(service).toBeTruthy();
  }));
});
