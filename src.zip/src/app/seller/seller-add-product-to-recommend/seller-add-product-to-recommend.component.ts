import { Component, OnInit, Input } from '@angular/core';
import { Seller } from '../../shared/models/seller';
import { Product } from '../../shared/models/product';
import { SellerAddProductToRecommendService } from './seller-add-product-to-recommend.service';

@Component({
  selector: 'app-seller-add-product-to-recommend',
  templateUrl: './seller-add-product-to-recommend.component.html',
  styleUrls: ['./seller-add-product-to-recommend.component.css']
})
export class SellerAddProductToRecommendComponent implements OnInit {

  errorMessage:string="";
  successMessage:string="";
  seller:Seller;

  @Input()
  product:Product;
  display:Boolean=false;
  displayProducts:Product[];
  dispError:Boolean=false;
  constructor(private sellerAddProductToRecommendService:SellerAddProductToRecommendService) { }

  ngOnInit() {
    this.seller=JSON.parse(sessionStorage.getItem("seller"));
    this.sellerAddProductToRecommendService.displayAllProducts(this.seller)
    .then(response => {
      this.displayProducts=response
    })
    this.display=true;
  }

  addNewRecommendation(product:Product){
    this.errorMessage=null;
    this.successMessage=null;
    this.sellerAddProductToRecommendService.addNewRecommendation(product.productId,this.seller.emailId)
    .then(response => {
      this.dispError=false;
      this.successMessage=response;
      this.display=true;
      
    })
    .catch((error) =>{
    this.errorMessage=error._body;
    this.dispError=true;});
  }
 

}
