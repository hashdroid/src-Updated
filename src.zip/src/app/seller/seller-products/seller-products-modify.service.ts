import { Injectable } from '@angular/core';
import { Http, Headers } from "@angular/http";
import { Product } from '../../shared/models/product';
import { environment } from '../../../environments/environment';

@Injectable()
export class SellerProductsModifyService {
  private headers = new Headers({ 'Content-Type': 'application/json' });

  constructor(private http: Http) { }

  getProductCategories(): Promise<string[]> {
    const url = environment.productAPIUrl + "/getProductCategories";
    return this.http.get(url)
      .toPromise()
      .then((response) => <string[]>response.json())
      .catch(this.errorHandeler)
  }

  updateProductDetails(product: Product, sellerEmailId: string): Promise<any> {
    const url = environment.SellerProductManagementAPI + "/modifyProductDetails/" + sellerEmailId;
    return this.http.post(url, JSON.stringify(product), { headers: this.headers })
      .toPromise()
      .then((response) => JSON.parse(JSON.stringify(response))._body)
      .catch(this.errorHandeler)

  }

  removeProductFromSeller(product: Product, sellerEmailId: string): Promise<any> {
    const url = environment.SellerProductManagementAPI + "/removeProducts/" + sellerEmailId;
    return this.http.post(url, JSON.stringify(product), { headers: this.headers })
      .toPromise()
      .then((response) => JSON.parse(JSON.stringify(response))._body)
      .catch(this.errorHandeler)

  }

  private errorHandeler(error: any): Promise<any> {
    console.error("Error Occured:\n", error);
    return Promise.reject(JSON.parse(JSON.stringify(error)));
  }
}

