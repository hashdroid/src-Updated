import { Component, OnInit } from '@angular/core';
import { SellerViewRecommendedProductsService } from './seller-view-recommended-products.service';
import { Router } from '@angular/router';
import { RecommendedProduct } from '../../shared/models/recommendedProduct';
import { Response } from '@angular/http/src/static_response';
import { Seller } from '../../shared/models/seller';
import { Input } from '@angular/core';

@Component({
  selector: 'app-seller-view-recommended-products',
  templateUrl: './seller-view-recommended-products.component.html',
  styleUrls: ['./seller-view-recommended-products.component.css']
})
export class SellerViewRecommendedProductsComponent implements OnInit {

  constructor(private recommendedProductService:SellerViewRecommendedProductsService,private router:Router)
   { }
sellerRecommededProducts:RecommendedProduct[];
successMessage:string;
errorMessage:string;
seller:Seller;
display:Boolean=false;
dispError:Boolean=false;
emptyList:Boolean=false;
@Input()
recomended:RecommendedProduct;

  ngOnInit() {
    this.seller=JSON.parse(sessionStorage.getItem("seller"));
    this.recommendedProductService.recommendProduct()
    .then(response=>this.sellerRecommededProducts=response
          )
    .catch(response=>{this.sellerRecommededProducts=response;
      this.dispError=true;});
    this.display=true;
  }
  removeProduct(recomended:RecommendedProduct)
  {
    this.recommendedProductService.removeProduct(this.seller.emailId,recomended.recommendationId)
    .then((response)=>{
      this.dispError=false;
      this.successMessage=response;
      this.errorMessage="";
      let newList:RecommendedProduct[]=[];
      for(let product of this.sellerRecommededProducts)
      {
        if(product.recommendationId!=recomended.recommendationId)
        {
          newList.push(product);
        }
      }
      this.sellerRecommededProducts=newList;
      sessionStorage.setItem("recomended",JSON.stringify(this.sellerRecommededProducts));
    })
    .catch((error)=>
    {
      this.errorMessage=error._body;
      this.successMessage="";
    })
  }


}
