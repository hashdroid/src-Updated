import { RecommendedDatePipe } from './recommended-date.pipe';

describe('RecommendedDatePipe', () => {
  it('create an instance', () => {
    const pipe = new RecommendedDatePipe();
    expect(pipe).toBeTruthy();
  });
});
