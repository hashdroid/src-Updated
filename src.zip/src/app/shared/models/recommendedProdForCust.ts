import { Product } from "./product";



export class RecommendedProdForCust{
    recommendationId:Number;
    recommendationTime:Date;
    product:Product;
}