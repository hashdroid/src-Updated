import { Product } from "./product";



export class RecommendedProduct{
    recommendationId:Number;
    productId:Product;
    recommendationTimestamp:Date;
    recommendationStatus:String;
    message:String;
}