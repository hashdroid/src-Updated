export class Orders{
    customerEmailId:string;
    orderNumber:number;
    orderId:number;
    dateOfOrder:Date;
    productId:number;
    quantity:number;
    totalPrice:number;
    orderStatus:string;
    addressId:number;
}