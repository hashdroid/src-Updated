import { Injectable } from "@angular/core";
import { Http, Headers } from "@angular/http";
import { Customer } from "../../shared/models/customer";
import { environment } from "../../../environments/environment";

@Injectable()
export class LoginService {
    private headers = new Headers({ 'Content-Type': 'application/json' });
    constructor(private http: Http) {

    }
    login(customer: Customer): Promise<any> {
        const url = environment.customerAPIUrl + '/customerLogin';
        return this.http.post(url, JSON.stringify(customer), { headers: this.headers }).toPromise()
            .then(
            (response) => response.json() as Customer
            ).catch(
            this.errorHandeler
            )

    }



    private errorHandeler(error: any): Promise<any> {
        console.error("Error Occured:\n", error);
        return Promise.reject(error.json() || error);
    }
}