package com.ekart.dao;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;





import java.util.Map;

import javax.persistence.Query;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Root;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.ekart.entity.RecommendedProductEntity;
import com.ekart.model.Product;
import com.ekart.model.RecommendedProduct;


@Repository(value="customerRecommendationProductDAO")
public class CustomerRecommendationProductDAOImpl implements CustomerRecommendationProductDAO {
	
	@Autowired
	private SessionFactory sessionFactory;
	
	@Override
	public List<RecommendedProduct> viewRecommendedProduct(){
		Session session=sessionFactory.getCurrentSession();
		CriteriaBuilder builder=session.getCriteriaBuilder();
		CriteriaQuery<RecommendedProductEntity> criteriaQuery = builder.createQuery(RecommendedProductEntity.class);
		Root<RecommendedProductEntity> root=criteriaQuery.from(RecommendedProductEntity.class);
		criteriaQuery.select(root).distinct(true);
		criteriaQuery.where(builder.equal(root.get("recommendationStatus"),"ACTIVE"));
		criteriaQuery.orderBy(builder.desc(root.get("recommendationTimestamp")));
		Query query=session.createQuery(criteriaQuery);
		List<RecommendedProductEntity> recommendedProductEntity=query.getResultList();
		List<RecommendedProduct> recommendedList=new ArrayList<>();
		for(RecommendedProductEntity recProductEntity:recommendedProductEntity){
			RecommendedProduct rp=new RecommendedProduct();
			Product prod=new Product();
			prod.setProductId(recProductEntity.getProductEntity().getProductId());
			prod.setName(recProductEntity.getProductEntity().getName());
			prod.setBrand(recProductEntity.getProductEntity().getBrand());
			prod.setPrice(recProductEntity.getProductEntity().getPrice());
			prod.setDiscount(recProductEntity.getProductEntity().getDiscount());
			rp.setProduct(prod);
			rp.setrecommendationStatus(recProductEntity.getRecommendationStatus());
			rp.setrecommendationId(recProductEntity.getRecommendationId());
			rp.setrecommendationTimestamp(recProductEntity.getRecommendationTimestamp());
			recommendedList.add(rp);

		}
		

		List<Integer> recProductId=new ArrayList<>();
		List<RecommendedProduct>recommendedList1=new ArrayList<>();
		if(!recommendedList.isEmpty())
		{
			for(RecommendedProduct i:recommendedList)
			{
				if(!recProductId.contains(i.getProduct().getProductId()))
				{
					recommendedList1.add(i);
					recProductId.add(i.getProduct().getProductId());
				}
			}
		}
		if(recommendedList.isEmpty())
			return null;
		else
		{
			Collections.sort(recommendedList1,(r1,r2)->r1.getrecommendationTimestamp().compareTo(r2.getrecommendationTimestamp()));
			Collections.reverse(recommendedList1);
		}
		
		return recommendedList1;
	}

}
