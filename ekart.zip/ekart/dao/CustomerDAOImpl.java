package com.ekart.dao;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Root;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.ekart.entity.AddressEntity;
import com.ekart.entity.CustomerCartEntity;
import com.ekart.entity.CustomerEntity;
import com.ekart.model.Address;
import com.ekart.model.Customer;
import com.ekart.model.CustomerCart;
import com.ekart.model.Product;

@Repository(value = "customerDAO")
public class CustomerDAOImpl implements CustomerDAO {

	@Autowired
	private SessionFactory sessionFactory;
	
	
	@Override
	public String getPasswordOfCustomer(String emailId) {
		
		String password = null;
		emailId = emailId.toLowerCase();
		Session session = sessionFactory.getCurrentSession();
		CustomerEntity customerEntity = session.get(CustomerEntity.class, emailId);
		if (customerEntity!=null){
			password = customerEntity.getPassword();
		}
		
		return password;
	}


	@Override
	public Customer getCustomerByEmailId(String emailId) {

		Customer customer = null;
		emailId = emailId.toLowerCase();
		List<Address> customerAddresses = new ArrayList<>();
		
		Session session = sessionFactory.getCurrentSession();
		CustomerEntity customerEntity = session.get(CustomerEntity.class, emailId);
		if (customerEntity!=null){
			customer = new Customer();
			customer.setEmailId(customerEntity.getEmailId());
			customer.setName(customerEntity.getName());
			//customer.setPassword(customerEntity.getPassword());
			customer.setPhoneNumber(customerEntity.getPhoneNumber());
			for (AddressEntity i : customerEntity.getAddressEntities()) {
				Address address = new Address();
				address.setAddressId(i.getAddressId());
				address.setAddressLine1(i.getAddressLine1());
				address.setAddressLine2(i.getAddressLine2());
				address.setCity(i.getCity());
				address.setContactNumber(i.getContactNumber());
				address.setPin(i.getPin());
				address.setState(i.getState());
				
				customerAddresses.add(address);
			}
			customer.setAddresses(customerAddresses);
			
			List<CustomerCart> customerCarts = new ArrayList<>();
			for (CustomerCartEntity customerCartEntity : customerEntity.getCustomerCarts()) {	
				CustomerCart cart = new CustomerCart();
				cart.setCartId(customerCartEntity.getCartId());
				cart.setQuantity(customerCartEntity.getQuantity());
					Product product = new Product();
					product.setBrand(customerCartEntity.getProductEntity().getBrand());
					product.setCategory(customerCartEntity.getProductEntity().getCategory());
					product.setDescription(customerCartEntity.getProductEntity().getDescription());
					product.setDiscount(customerCartEntity.getProductEntity().getDiscount());
					product.setName(customerCartEntity.getProductEntity().getName());
					product.setPrice(customerCartEntity.getProductEntity().getPrice());
					product.setProductId(customerCartEntity.getProductEntity().getProductId());
					product.setQuantity(customerCartEntity.getProductEntity().getQuantity());
				
				cart.setProduct(product);
				
				customerCarts.add(cart);
			}
			customer.setCustomerCarts(customerCarts);
			
		}
		
		return customer;
	}
	
	@Override
	public Boolean checkAvailabilityOfEmailId(String emailId) {
		
		Boolean flag = false;

		CustomerEntity customerEntity = null;

		emailId = emailId.toLowerCase();

		Session session  = sessionFactory.getCurrentSession();

		customerEntity = session.get(CustomerEntity.class, emailId);

		if(customerEntity == null)
			flag = true;

		return flag;
	}

	@Override
	public Boolean checkRegisteredPhoneNumber(String phoneNumber) {
		
		Boolean flag = false;

		CustomerEntity customerEntity = null;

		Session session  = sessionFactory.getCurrentSession();

		CriteriaBuilder builder = session.getCriteriaBuilder();

		CriteriaQuery<CustomerEntity> criteria = builder.createQuery(CustomerEntity.class);
		Root<CustomerEntity> root = criteria.from(CustomerEntity.class);
		criteria.where(builder.equal(root.get("phoneNumber"), phoneNumber));
		customerEntity = session.createQuery(criteria).uniqueResult();
		if(customerEntity == null)
			flag = true;

		return flag;
	}

	@Override
	public String registerNewCustomer(Customer customer) {
		
		String registeredWithEmailId = null;

		Session session = sessionFactory.getCurrentSession();

		CustomerEntity customerEntity = new CustomerEntity();

		customerEntity.setEmailId(customer.getEmailId().toLowerCase());
		customerEntity.setName(customer.getName());
		customerEntity.setPassword(customer.getPassword());
		customerEntity.setPhoneNumber(customer.getPhoneNumber());
		
		registeredWithEmailId = (String) session.save(customerEntity);

		return registeredWithEmailId;
	}
	
	
	@Override
	public Customer getCustomerByPhoneNo(String phoneNumber) {
		
		CustomerEntity customerEntity = null;
		Customer customer=null;

		Session session  = sessionFactory.getCurrentSession();

		CriteriaBuilder builder = session.getCriteriaBuilder();

		CriteriaQuery<CustomerEntity> criteria = builder.createQuery(CustomerEntity.class);
		Root<CustomerEntity> root = criteria.from(CustomerEntity.class);
		criteria.where(builder.equal(root.get("phoneNumber"), phoneNumber) );
		customerEntity = session.createQuery(criteria).uniqueResult();
		if(customerEntity!=null){
			customer = new Customer();
			customer.setEmailId(customerEntity.getEmailId());
			customer.setName(customerEntity.getName());
			customer.setPhoneNumber(customerEntity.getPhoneNumber());
			List<Address> addList=new ArrayList<>();
			for(AddressEntity ae:customerEntity.getAddressEntities()){
				Address a=new Address();
				a.setAddressId(ae.getAddressId());
				a.setAddressLine1(ae.getAddressLine1());
				a.setAddressLine2(ae.getAddressLine2());
				a.setCity(ae.getCity());
				a.setContactNumber(ae.getContactNumber());
				a.setPin(ae.getPin());
				a.setState(ae.getState());
				addList.add(a);
			}
			customer.setAddresses(addList);
			
			List<CustomerCart> customerCarts = new ArrayList<>();
			for (CustomerCartEntity customerCartEntity : customerEntity.getCustomerCarts()) {	
				CustomerCart cart = new CustomerCart();
				cart.setCartId(customerCartEntity.getCartId());
				cart.setQuantity(customerCartEntity.getQuantity());
					Product product = new Product();
					product.setBrand(customerCartEntity.getProductEntity().getBrand());
					product.setCategory(customerCartEntity.getProductEntity().getCategory());
					product.setDescription(customerCartEntity.getProductEntity().getDescription());
					product.setDiscount(customerCartEntity.getProductEntity().getDiscount());
					product.setName(customerCartEntity.getProductEntity().getName());
					product.setPrice(customerCartEntity.getProductEntity().getPrice());
					product.setProductId(customerCartEntity.getProductEntity().getProductId());
					product.setQuantity(customerCartEntity.getProductEntity().getQuantity());
				
				cart.setProduct(product);
				
				customerCarts.add(cart);
			}
			customer.setCustomerCarts(customerCarts);
		}
			
		return customer; 
	}
	
	@Override
	public void updateProfile(Customer customer) {

		Session session  = sessionFactory.getCurrentSession();

		CustomerEntity customerEntity = session.get(CustomerEntity.class, customer.getEmailId().toLowerCase());
		
		customerEntity.setName(customer.getName());
		customerEntity.setPhoneNumber(customer.getPhoneNumber());
		
	}
	
	@Override
	public void changePassword(String customerEmailId, String newHashedPassword) {

		Session session  = sessionFactory.getCurrentSession();
		
		CustomerEntity customerEntity = session.get(CustomerEntity.class, customerEmailId);
		
		customerEntity.setPassword(newHashedPassword);

	}
	
	
	@Override
	public Integer addShippingAddress(String customerEmailId, Address address) {
		
		CustomerEntity customerEntity = null;
		
		Integer newAddressId = null;
		
		Session session  = sessionFactory.getCurrentSession();

		customerEntity = session.get(CustomerEntity.class, customerEmailId);
		
		List<AddressEntity> customerAddressEntities = customerEntity.getAddressEntities();
		
		AddressEntity newShippingAddress = new AddressEntity();
		newShippingAddress.setAddressLine1(address.getAddressLine1());
		newShippingAddress.setAddressLine2(address.getAddressLine2());
		newShippingAddress.setCity(address.getCity());
		newShippingAddress.setContactNumber(address.getContactNumber());
		newShippingAddress.setPin(address.getPin());
		newShippingAddress.setState(address.getState());
		
		customerAddressEntities.add(newShippingAddress);
		customerEntity.setAddressEntities(customerAddressEntities);
		
		session.persist(customerEntity);
		
		
		List<AddressEntity> customerAddressEntitiesAfterAddition = customerEntity.getAddressEntities();
		
		AddressEntity newAddress = customerAddressEntitiesAfterAddition.get(customerAddressEntitiesAfterAddition.size()-1);
		newAddressId = newAddress.getAddressId();
		return newAddressId;
	}
	
	@Override
	public void updateShippingAddress(Address address) {

		Session sessionAddress  = sessionFactory.getCurrentSession();
		AddressEntity addressEntity=sessionAddress.get(AddressEntity.class, address.getAddressId());
		addressEntity.setAddressLine1(address.getAddressLine1());
		addressEntity.setAddressLine2(address.getAddressLine2());
		addressEntity.setCity(address.getCity());
		addressEntity.setContactNumber(address.getContactNumber());
		addressEntity.setPin(address.getPin());
		addressEntity.setState(address.getState());
		
	}

	@Override
	public void deleteShippingAddress(String customerEmailId, Integer addressId) {

		Session session  = sessionFactory.getCurrentSession();
		CustomerEntity customerEntity = session.get(CustomerEntity.class, customerEmailId);
		List<AddressEntity> customerAddressEntities = customerEntity.getAddressEntities();
		AddressEntity addressEntity = session.get(AddressEntity.class, addressId);
		
		customerAddressEntities.remove(addressEntity);
		
		session.delete(addressEntity);
	}

}
