package com.ekart.dao;

import java.util.List;

import com.ekart.model.CustomerCart;
import com.ekart.model.Product;

public interface CustomerCartDAO {

	public void addProductToCart(String customerEmailId, CustomerCart customerCart);
	public List<CustomerCart> getCustomerCart(String customerEmailId);
	public void modifyQuantityToCart(Integer cartId, Integer quantity);
	public void deleteProductFromCart(String customerEmailId, Integer cartId);
	public Product getProductById(Integer productId);
}
