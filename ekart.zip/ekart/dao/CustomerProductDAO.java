package com.ekart.dao;

import java.util.List;

import com.ekart.model.Product;

public interface CustomerProductDAO {
	public List<Product> getAllProducts();
}
