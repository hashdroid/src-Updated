package com.ekart.dao;

import com.ekart.model.Seller;

public interface SellerDAO {

	public String getPasswordOfSeller(String emailId);

	public Seller getSellerByEmailId(String emailId) throws Exception;
	
	public Boolean checkAvailabilityOfEmailId(String emailId);
	
	public Boolean checkRegisteredPhoneNumber(String phoneNumber);
	
	public String registerNewSeller(Seller seller);
	
	public Seller getSellerByPhoneNo(String phoneNumber);
	
	public void updateProfile(Seller seller);
	
	public void changePassword(String sellerEmailId, String newHashedPassword);

}
