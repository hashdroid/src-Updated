package com.ekart.entity;

import java.time.LocalDateTime;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import org.hibernate.annotations.GenericGenerator;


@Entity
@Table(name="EKART_RECOMMENDED_PRODUCT")
@GenericGenerator(name="pkgen",strategy="increment")
public class RecommendedProductEntity {
	
	@Id
	@GeneratedValue(generator="pkgen")
	@Column(name="recommendation_id")
	private Integer recommendationId;
	
	@ManyToOne(cascade=CascadeType.ALL)
	@JoinColumn(name="PRODUCT_ID")
	private ProductEntity productEntity;
	
	@Column(name="recommendation_timestamp")
	private LocalDateTime recommendationTimestamp;
	
	@Column(name="recommendation_status")
	private String recommendationStatus;
	
	public Integer getRecommendationId() {
		return recommendationId;
	}
	public void setRecommendationId(Integer recommendationId) {
		this.recommendationId = recommendationId;
	}
	public LocalDateTime getRecommendationTimestamp() {
		return recommendationTimestamp;
	}
	public void setRecommendationTimestamp(LocalDateTime recommendationTimestamp) {
		this.recommendationTimestamp = recommendationTimestamp;
	}
	public String getRecommendationStatus() {
		return recommendationStatus;
	}
	public void setRecommendationStatus(String recommendationStatus) {
		this.recommendationStatus = recommendationStatus;
	}
	public ProductEntity getProductEntity() {
		return productEntity;
	}
	public void setProductEntity(ProductEntity productEntity) {
		this.productEntity = productEntity;
	}
	
	
	
	
	

}
