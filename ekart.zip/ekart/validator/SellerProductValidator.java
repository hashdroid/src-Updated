package com.ekart.validator;

import com.ekart.model.Product;

public class SellerProductValidator {

	public static void validateProduct(Product product) throws Exception{
		if(! isValidProductName(product.getName()))
			throw new Exception("SellerProductValidator.INVALID_NAME");
		
		if(! isValidProductDescription(product.getDescription()))
			throw new Exception("SellerProductValidator.INVALID_DESCRIPTION");
		
		if(!isValidDiscount(product.getDiscount()))
			throw new Exception("SellerProductValidator.INVALID_DISCOUNT");
		
		if(!isValidQuantity(product.getQuantity()))
			throw new Exception("SellerProductValidator.INVALID_QUANTITY");
		
		if(!isValidPrice(product.getPrice() ) )
			throw new Exception("SellerProductValidator.INVALID_PRICE");
	}
	
	public static Boolean isValidProductName(String productName){
		Boolean flag = false;
		if(!productName.matches("[ ]*") && productName.matches("([A-Za-z0-9-.])+(\\s[A-Za-z0-9-.]+)*"))
			flag=true;
		return flag;
		
	}
	
	public static Boolean isValidProductDescription(String productDescription){
		Boolean flag = false;
		if(! productDescription.matches("[ ]*"))
			flag=true;
		return flag;
		
	}
	
	public static Boolean isValidDiscount(Double discount){
		Boolean flag = false;
		if(discount>=0.0 && discount<=100.0)
			flag = true;
		return flag;
		
	}
	
	
	public static Boolean isValidQuantity(Integer quantity){
		Boolean flag = false;
		if(quantity>0)
			flag = true;
		return flag;
		
	}
	
	public static Boolean isValidPrice(Double price){
		Boolean flag = false;
		if(price>0.0)
			flag = true;
		return flag;
		
	}
}
