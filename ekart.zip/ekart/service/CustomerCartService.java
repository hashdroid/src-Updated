package com.ekart.service;

import java.util.List;

import com.ekart.model.CustomerCart;

public interface CustomerCartService {

	public void addProductToCart(String customerEmailId, CustomerCart customerCart) throws Exception;
	public List<CustomerCart> getCustomerCart(String customerEmailId) throws Exception;
	public void modifyQuantityToCart(Integer cartId, Integer quantity, Integer productId) throws Exception;
	public void deleteProductFromCart(String customerEmailId, Integer cartId);
	
}
