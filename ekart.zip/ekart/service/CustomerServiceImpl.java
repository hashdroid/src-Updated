package com.ekart.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.ekart.dao.CustomerDAO;
import com.ekart.model.Address;
import com.ekart.model.Customer;
import com.ekart.utility.HashingUtility;
import com.ekart.validator.CustomerValidator;

@Service( value = "customerService" )
@Transactional(readOnly = true)
public class CustomerServiceImpl implements CustomerService {
	
	@Autowired
	private CustomerDAO customerDAO;
	
	@Override
	public Customer authenticateCustomer(String emailId, String password)
			throws Exception{

		Customer customer = null;
		
		Boolean validEmailFormat = CustomerValidator.validateEmailId(emailId);
		
		if(! validEmailFormat)
			throw new Exception("CustomerService.INVALID_CREDENTIALS");
		
		String passwordFromDB = customerDAO.getPasswordOfCustomer(emailId.toLowerCase());
		if(passwordFromDB!=null){
			String hashedPassword = HashingUtility.getHashValue(password);
			
			if(hashedPassword.equals(passwordFromDB)){
				customer  = customerDAO.getCustomerByEmailId(emailId);
			}
			else
				throw new Exception ("CustomerService.INVALID_CREDENTIALS");
		}
		else
			throw new Exception ("CustomerService.INVALID_CREDENTIALS");
		
		return customer;
		
	}
	
	@Override
	@Transactional(readOnly=false, propagation=Propagation.REQUIRES_NEW)
	public String registerNewCustomer(Customer customer)
			throws Exception {
		
		String registeredWithEmailId = null;

		CustomerValidator.validateCustomer(customer);
		Boolean emailAvailable = customerDAO.checkAvailabilityOfEmailId(customer.getEmailId());
		Boolean phoneNumberAvailable = customerDAO.checkRegisteredPhoneNumber(customer.getPhoneNumber());
		if(emailAvailable){
			if(phoneNumberAvailable){
				String emailIdToDB = customer.getEmailId().toLowerCase();
				String passwordToDB = HashingUtility.getHashValue(customer.getPassword());

				customer.setEmailId(emailIdToDB);
				customer.setPassword(passwordToDB);

				registeredWithEmailId = customerDAO.registerNewCustomer(customer);

			}
			else{
				throw new Exception("CustomerService.PHONE_NUMBER_ALREADY_IN_USE");
			}
		}
		else{
			throw new Exception("CustomerService.EMAIL_ID_ALREADY_IN_USE");
		}


		return registeredWithEmailId;
	}
	
	@Override
	@Transactional(readOnly=false, propagation=Propagation.REQUIRES_NEW)
	public void updateProfile(Customer customer) throws  Exception {
		
		Customer newCustomer=null;
		CustomerValidator.validateCustomerForUpdateProfile(customer);

		newCustomer=customerDAO.getCustomerByPhoneNo(customer.getPhoneNumber());
		if(newCustomer==null){
			customerDAO.updateProfile(customer);
		}
		else{
			if(newCustomer.getEmailId().equals(customer.getEmailId()))
				customerDAO.updateProfile(customer);
			else
				throw new Exception("CustomerService.PHONE_NUMBER_ALREADY_IN_USE");
		}
	}

	@Override
	@Transactional(readOnly=false, propagation=Propagation.REQUIRES_NEW)
	public void changePassword(String customerEmailId, String currentPassword, String newPassword)
			throws Exception {

		Boolean validPWD = CustomerValidator.validatePassword(newPassword);
		if (!validPWD)
			throw new Exception("CustomerService.INVALID_NEW_PASSWORD");
		
		String hashedPasswordFromDao = customerDAO.getPasswordOfCustomer(customerEmailId);
		String hashedCurrentPassword = HashingUtility.getHashValue(currentPassword);
		
		if(!hashedPasswordFromDao.equals(hashedCurrentPassword))
			throw new Exception("CustomerService.INVALID_CURRENT_PASSWORD");
		
		if(currentPassword.equals(newPassword))
			throw new Exception("CustomerService.OLD_PASSWORD_NEW_PASSWORD_SAME");
		
		String newHashedPassword = HashingUtility.getHashValue(newPassword);
		customerDAO.changePassword(customerEmailId, newHashedPassword);

	}
	
	@Override
	@Transactional(readOnly=false, propagation=Propagation.REQUIRES_NEW)
	public Integer addShippingAddress(String customerEmailId, Address address)
			throws Exception {
		
		CustomerValidator.validateAddress(address);
		Integer newAddressID = customerDAO.addShippingAddress(customerEmailId, address);
		
		return newAddressID; 
	}
	
	@Override
	@Transactional(readOnly=false, propagation=Propagation.REQUIRES_NEW)
	public void updateShippingAddress(Address address) throws Exception {
		
		CustomerValidator.validateAddress(address);
		customerDAO.updateShippingAddress(address);
		
	}
	

	@Override
	@Transactional(readOnly=false, propagation=Propagation.REQUIRES_NEW)
	public void deleteShippingAddress(String customerEmailId, Integer addressId)
			throws Exception {
		
		customerDAO.deleteShippingAddress(customerEmailId, addressId );
	}

	
}
