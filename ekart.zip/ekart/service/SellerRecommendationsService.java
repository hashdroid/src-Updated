package com.ekart.service;

import java.util.List;

import com.ekart.model.Product;
import com.ekart.model.RecommendedProduct;

public interface SellerRecommendationsService {
	
	public List<RecommendedProduct> getRecommendedProducts(String emailId) throws Exception;
	public String removeRecommendedProducts(String emailId, Integer recommendationId) throws Exception;
	public Integer addRecommendedProducts(String emailId, Integer productId) throws Exception;
	public List<Product> getAllProducts(String emailId) throws Exception;
}
