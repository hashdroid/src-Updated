package com.ekart.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.ekart.dao.SellerProductDAO;
import com.ekart.model.Product;
import com.ekart.validator.SellerProductValidator;


@Service( value = "sellerProductService" )
@Transactional(readOnly = true)
public class SellerProductServiceImpl implements
		SellerProductService {
	
	@Autowired
	private SellerProductDAO sellerProductDAO;
	
	@Override
	@Transactional(readOnly=false, propagation=Propagation.REQUIRES_NEW)
	public Integer addNewProduct(Product product, String sellerEmailId) throws Exception {
		
		SellerProductValidator.validateProduct(product);

		Integer productId = sellerProductDAO.addNewProduct(product,sellerEmailId);
		
		return productId;
	}
	
	@Override
	@Transactional(readOnly=false, propagation=Propagation.REQUIRES_NEW)
	public Product modifyProductDetails(Product productForModification,String sellerEmailId)
			throws Exception {
		
		
		SellerProductValidator.validateProduct(productForModification);
		
		Product product = sellerProductDAO.modifyProductDetails(productForModification,sellerEmailId);
		
		return product;
	}


	@Override
	@Transactional(readOnly=false, propagation=Propagation.REQUIRES_NEW)
	public Integer removeProduct(Integer productId,String sellerEmailId) {

		return sellerProductDAO.removeProduct(productId,sellerEmailId);
		
	}
	
	@Override
	public List<String> getProductCategoryList() throws Exception {
		
		return sellerProductDAO.getProductCategoryList();
	}

}
