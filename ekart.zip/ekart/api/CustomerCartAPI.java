package com.ekart.api;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.ekart.model.CustomerCart;
import com.ekart.service.CustomerCartService;
import com.ekart.service.CustomerCartServiceImpl;
import com.ekart.utility.ContextFactory;


@CrossOrigin
@RestController
@RequestMapping("CustomerCartAPI")
public class CustomerCartAPI {

	@Autowired
	private Environment environment;
	
	@RequestMapping(value = "addProductToCart/{customerEmailId:.+}", method = RequestMethod.POST)
	public ResponseEntity<String> addProductToCart(@RequestBody CustomerCart customerCart, @PathVariable("customerEmailId") String customerEmailId) throws Exception {
		try
		{
			CustomerCartService customerCartService = ContextFactory.getContext().getBean(CustomerCartServiceImpl.class);
			customerCartService.addProductToCart(customerEmailId, customerCart);
			
			String message = environment.getProperty("CustomerCartAPI.PRODUCT_ADDED_TO_CART");
			
			return new ResponseEntity<String>(message, HttpStatus.OK);
			
		}
		catch(Exception e)
		{
			String message = environment.getProperty(e.getMessage());
			
			return new ResponseEntity<String>(message, HttpStatus.BAD_REQUEST);
			
		}
	}
	
	
	
	@RequestMapping(value = "getCustomerCart", method = RequestMethod.POST)
	public ResponseEntity<?> getCustomerCart(@RequestBody String customerEmailId) throws Exception{
		List<CustomerCart> list = null;
		
		try
		{
			
			CustomerCartService customerCartService = ContextFactory.getContext().getBean(CustomerCartService.class);
			list = customerCartService.getCustomerCart(customerEmailId);
			return new ResponseEntity<List<CustomerCart>>(list, HttpStatus.OK);
		}
		catch(Exception e)
		{
			String message = environment.getProperty(e.getMessage());
			
			return new ResponseEntity<String>(message, HttpStatus.BAD_REQUEST);
		}
	}
	
	
	
	@RequestMapping(value = "modifyQuantityInCart", method = RequestMethod.POST)
	public ResponseEntity<String> modifyQuantityToCart(@RequestBody CustomerCart customerCart) throws Exception{
		
		try
		{
			CustomerCartService customerCartService = ContextFactory.getContext().getBean(CustomerCartServiceImpl.class);
			
			customerCartService.modifyQuantityToCart(customerCart.getCartId(), customerCart.getQuantity(), customerCart.getProduct().getProductId());;
			
			String message = environment.getProperty("CustomerCartAPI.QUANTITY_UPDATE_SUCCESS");
			
			return new ResponseEntity<String>(message, HttpStatus.OK);
		}
		catch(Exception e)
		{
			String message = environment.getProperty(e.getMessage());
			
			return new ResponseEntity<String>(message, HttpStatus.BAD_REQUEST);
		}
	}
	
	
	
	@RequestMapping(value = "deleteProductFromCart/{customerEmailId:.+}", method = RequestMethod.POST)
	public ResponseEntity<String> deleteProductFromCart(@PathVariable("customerEmailId") String customerEmailId, @RequestBody String cartId) throws Exception{
		
		try
		{
			CustomerCartService customerCartService = ContextFactory.getContext().getBean(CustomerCartService.class);

			customerCartService.deleteProductFromCart(customerEmailId, Integer.parseInt(cartId));
			
			String message = environment.getProperty("CustomerCartAPI.PRODUCT_REMOVED_FROM_CART_SUCCESS");
			
			return new ResponseEntity<String>(message, HttpStatus.OK);
		}
		catch(Exception e)
		{
			String message = environment.getProperty(e.getMessage());
			
			return new ResponseEntity<String>(message, HttpStatus.BAD_REQUEST);
		}
	}
}
