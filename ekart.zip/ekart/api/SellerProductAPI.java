package com.ekart.api;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.ekart.model.Product;
import com.ekart.service.SellerProductService;
import com.ekart.utility.ContextFactory;


@CrossOrigin
@RestController
@RequestMapping("SellerProductAPI")
public class SellerProductAPI {
	
	@Autowired
	private Environment environment;
	
	@RequestMapping(value = "addProductToSellerCatalog/{sellerEmail:.+}", method = RequestMethod.POST)
	public ResponseEntity<?> addNewProductToSellerCatalog(@RequestBody Product product, @PathVariable ("sellerEmail") String sellerEmailId) throws Exception {
		try
		{
			SellerProductService sellerProductService = ContextFactory.getContext().getBean(SellerProductService.class);
			
			Integer newProductId = sellerProductService.addNewProduct(product, sellerEmailId);
			String successMessage = environment.getProperty("SellerProductAPI.PRODUCT_ADDED_SUCCESSFULLY")+newProductId;
			product.setSuccessMessage(successMessage);
			product.setProductId(newProductId);
			return new ResponseEntity<Product>(product, HttpStatus.OK);
			
		}
		catch(Exception e)
		{
			String message = environment.getProperty(e.getMessage());
			return new ResponseEntity<String>(message, HttpStatus.BAD_REQUEST);
		}
	}

	@RequestMapping(value = "modifyProductDetails/{sellerEmail:.+}", method = RequestMethod.POST)
	public ResponseEntity<?> modifyProductDetails(@RequestBody Product product, @PathVariable ("sellerEmail") String sellerEmailId) throws Exception {
		try
		{
			SellerProductService spmService = ContextFactory.getContext().getBean(SellerProductService.class);
			
			Product productReturned = spmService.modifyProductDetails(product, sellerEmailId);
			String successMessage = environment.getProperty("SellerProductAPI.PRODUCT_MODIFIED_SUCCESSFULLY")+productReturned.getProductId();
			productReturned.setSuccessMessage(successMessage);
			return new ResponseEntity<Product>(productReturned, HttpStatus.OK);
		}
		catch(Exception e)
		{
			String message = environment.getProperty(e.getMessage());
			return new ResponseEntity<String>(message, HttpStatus.BAD_REQUEST);
		}
	}
	
	@RequestMapping(value = "removeProduct/{sellerEmail:.+}", method = RequestMethod.POST)
	public ResponseEntity<?> removeProduct(@RequestBody Integer productId, @PathVariable ("sellerEmail") String sellerEmailId) throws Exception {
		try
		{
			SellerProductService sellerProductService = ContextFactory.getContext().getBean(SellerProductService.class);
			Integer deleteProduct = sellerProductService.removeProduct(productId, sellerEmailId);
			String successMessage = environment.getProperty("SellerProductAPI.PRODUCT_DELETED_SUCCESSFULLY")+deleteProduct;
			Product product = new Product();
			product.setProductId(deleteProduct);
			product.setSuccessMessage(successMessage);
			return new ResponseEntity<Product>(product, HttpStatus.OK);
		}
		catch(Exception e)
		{
			String message = environment.getProperty(e.getMessage());
			return new ResponseEntity<String>(message, HttpStatus.BAD_REQUEST);
		}
	}

	@RequestMapping(value = "getProductCategories", method = RequestMethod.GET)
	public ResponseEntity<List<String>> getProductCategories() throws Exception {
		try
		{
			SellerProductService sellerProductService = ContextFactory.getContext().getBean(SellerProductService.class);
			List<String> productCategories = sellerProductService.getProductCategoryList();
			return new ResponseEntity<List<String>>(productCategories, HttpStatus.OK);
		}
		catch(Exception e){
			String message = environment.getProperty(e.getMessage());
			List<String> strings = new ArrayList<>();
			strings.add(message);
			return new ResponseEntity<List<String>>(strings, HttpStatus.BAD_REQUEST);
		}
		
	}
	
	
}
