package com.ekart.api;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.PropertySource;
import org.springframework.core.env.Environment;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.ekart.model.Address;
import com.ekart.model.Customer;
import com.ekart.service.CustomerService;
import com.ekart.service.CustomerServiceImpl;
import com.ekart.utility.ContextFactory;

@CrossOrigin
@RestController
@RequestMapping("CustomerAPI")
@PropertySource("classpath:/com/ekart/resources/configuration.properties")
public class CustomerAPI {
	
	
	@Autowired
	private Environment environment;
	
	static Logger logger = LogManager.getLogger(CustomerAPI.class.getName());
	
	@RequestMapping(value = "customerLogin", method = RequestMethod.POST)
	public ResponseEntity<Customer> authenticateCustomer(@RequestBody Customer customer) throws Exception {
		try {
			logger.info("CUSTOMER TRYING TO LOGIN, VALIDATING CREDENTIALS. USER EMAIL : "+customer.getEmailId());
			
			CustomerService customerService = ContextFactory.getContext().getBean(CustomerServiceImpl.class);
			
			customer = customerService.authenticateCustomer(customer.getEmailId(), customer.getPassword());
			
			logger.info("CUSTOMER LOGIN SUCCESS, USER EMAIL : "+customer.getEmailId());
			
			return new ResponseEntity<Customer>(customer, HttpStatus.OK);
		} 
		catch (Exception e) {
			/*
			 * The following code populates a user model with an error message
			 */
			Customer customerWithErrorMsg = new Customer();
			customerWithErrorMsg.setErrorMessage(environment.getProperty(e.getMessage()));

			return new ResponseEntity<Customer>(customerWithErrorMsg, HttpStatus.BAD_REQUEST);
		}
	}
	
	@RequestMapping(value = "registerCustomer", method = RequestMethod.POST)
	public ResponseEntity<String> registerCustomer(@RequestBody Customer customer) throws Exception {
		
		try
		{
			CustomerService customerService = ContextFactory.getContext().getBean(CustomerServiceImpl.class);
			
			String registeredWithEmailID = customerService.registerNewCustomer(customer);
			registeredWithEmailID = environment.getProperty("CustomerAPI.SELLER_REGISTRATION_SUCCESS")+registeredWithEmailID;
			return new ResponseEntity<String>(registeredWithEmailID, HttpStatus.OK);
			
		}
		catch(Exception e)
		{
			String message = environment.getProperty(e.getMessage());
			
			return new ResponseEntity<String>(message, HttpStatus.BAD_REQUEST);
			
		}
	}
	
	@RequestMapping(value = "updateProfile", method = RequestMethod.POST)
	public ResponseEntity<String> updateProfile(@RequestBody Customer customer) throws Exception {

		try
		{
			CustomerService customerService = ContextFactory.getContext().getBean(CustomerServiceImpl.class);
			
			customerService.updateProfile(customer);
			String modificationSuccessMsg = environment.getProperty("CustomerAPI.CUSTOMER_DETAILS_UPDATION_SUCCESS");
			return new ResponseEntity<String>(modificationSuccessMsg, HttpStatus.OK);
			
		}
		catch(Exception e)
		{
			String message = environment.getProperty(e.getMessage());
			
			return new ResponseEntity<String>(message, HttpStatus.BAD_REQUEST);
		}
	}
	
	@RequestMapping(value = "changePassword", method = RequestMethod.POST)
	public ResponseEntity<String> changePassword(@RequestBody Customer customer) throws Exception {

		try
		{
			CustomerService customerService = ContextFactory.getContext().getBean(CustomerServiceImpl.class);
			
			customerService.changePassword(customer.getEmailId(), customer.getPassword(), customer.getNewPassword());
			String modificationSuccessMsg = environment.getProperty("CustomerAPI.CUSTOMER_PASSWORD_CHANGE_SUCCESS");
			return new ResponseEntity<String>(modificationSuccessMsg, HttpStatus.OK);
			
		}
		catch(Exception e)
		{
			String message = environment.getProperty(e.getMessage());
			
			return new ResponseEntity<String>(message, HttpStatus.BAD_REQUEST);
		}
	}
	
	@RequestMapping(value = "addNewShippingAddress/{customerEmailId:.+}", method = RequestMethod.POST)
	public ResponseEntity<String> addNewShippingAddress(@RequestBody Address address, @PathVariable("customerEmailId") String customerEmailId) throws Exception {
		int addressId;
		
		try
		{
			CustomerService customerService = ContextFactory.getContext().getBean(CustomerServiceImpl.class);
			addressId = customerService.addShippingAddress(customerEmailId,address);
			String message=environment.getProperty("CustomerAPI.NEW_SHIPPING_ADDRESS_ADDED_SUCCESS");
			String ret = message+addressId;
			
			ret = ret.trim();
			return new ResponseEntity<String>(ret, HttpStatus.OK);
		}
		catch(Exception e){
			String message = environment.getProperty(e.getMessage());
			return new ResponseEntity<String>(message, HttpStatus.BAD_REQUEST);
		}
	}
	
	@RequestMapping(value = "updateShippingAddress", method = RequestMethod.POST)
	public ResponseEntity<String> updateShippingAddress(@RequestBody Address address) throws Exception {
		try
		{
			CustomerService customerService = ContextFactory.getContext().getBean(CustomerServiceImpl.class);
			customerService.updateShippingAddress(address);
			String modificationSuccessMsg=environment.getProperty("CustomerAPI.UPDATE_ADDRESS_SUCCESS");
			return new ResponseEntity<String>(modificationSuccessMsg, HttpStatus.OK);
		}
		catch(Exception e){
			
			String message = environment.getProperty(e.getMessage());
			return new ResponseEntity<String>(message, HttpStatus.BAD_REQUEST);
		}
	}
	
	@RequestMapping(value = "deleteShippingAddress/{addressId}/{customerEmailId:.+}", method = RequestMethod.POST)
	public ResponseEntity<String> deleteShippingAddress(@PathVariable("addressId") Integer addressId, @PathVariable("customerEmailId") String customerEmailId) throws Exception {

		try
		{
			CustomerService customerService = ContextFactory.getContext().getBean(CustomerService.class);
			
			customerService.deleteShippingAddress(customerEmailId, addressId);
			String modificationSuccessMsg = environment.getProperty("CustomerAPI.CUSTOMER_ADDRESS_DELETED_SUCCESS");
			return new ResponseEntity<String>(modificationSuccessMsg, HttpStatus.OK);
			
		}
		catch(Exception e)
		{
			String message = environment.getProperty(e.getMessage());
			
			return new ResponseEntity<String>(message, HttpStatus.BAD_REQUEST);
			
		}
	}
}
