package com.ekart.api;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.ekart.model.Product;
import com.ekart.service.CustomerProductService;
import com.ekart.utility.ContextFactory;

@CrossOrigin
@RestController
@RequestMapping("CustomerProductAPI")
public class CustomerProductAPI {

	@Autowired
	private Environment environment;
	
	@RequestMapping(value = "getAllProducts", method = RequestMethod.GET)
	public ResponseEntity<List<Product>> getAllProducts() throws Exception {
		
		List<Product> products = null;
		try
		{
			CustomerProductService customerProductService = ContextFactory.getContext().getBean(CustomerProductService.class);
			
			products = customerProductService.getAllProducts();
			
			return new ResponseEntity<List<Product>>(products, HttpStatus.OK);
		}
		catch(Exception e){
			String message = environment.getProperty(e.getMessage());
			
			Product product = new Product();
			product.setErrorMessage(message);
			products = new ArrayList<Product>();
			products.add(product);
			
			return new ResponseEntity<List<Product>>(products, HttpStatus.BAD_REQUEST);
		}
		
	}
}
