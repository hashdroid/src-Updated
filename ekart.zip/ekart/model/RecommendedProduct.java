package com.ekart.model;


import java.time.LocalDateTime;

public class RecommendedProduct {
	
	private Integer recommendationId;
	private Product product;
	private LocalDateTime recommendationTimestamp;
	private String recommendationStatus;
	private String message;
	
	public Integer getrecommendationId() {
		return recommendationId;
	}
	public void setrecommendationId(Integer recommendationId) {
		this.recommendationId = recommendationId;
	}
	public String getrecommendationStatus() {
		return recommendationStatus;
	}
	public void setrecommendationStatus(String recommendationStatus) {
		this.recommendationStatus = recommendationStatus;
	}
	public LocalDateTime getrecommendationTimestamp() {
		return recommendationTimestamp;
	}
	public void setrecommendationTimestamp(LocalDateTime recommendationTimestamp) {
		this.recommendationTimestamp = recommendationTimestamp;
	}
	public Product getProduct() {
		return product;
	}
	public void setProduct(Product product) {
		this.product = product;
	}
	public String getMessage() {
		return message;
	}
	public void setMessage(String message) {
		this.message = message;
	}
	
	

}
